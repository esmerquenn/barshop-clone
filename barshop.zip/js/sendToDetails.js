function goToDetailPage(id){
    window.location.href = `details.html?id=${id}`;
    
  }